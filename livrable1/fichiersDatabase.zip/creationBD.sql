--Fichier contenant le script de création de la BD, les insertions des données de base et le script d'activation du mode REST 

--Création de la table Club

CREATE TABLE club (
    id_club            NUMBER NOT NULL,
    nom                VARCHAR2(100) NOT NULL,
    proprietaire       VARCHAR2(100) NOT NULL,
    tournoi_id_tournoi NUMBER
);

ALTER TABLE club ADD CONSTRAINT club_pk PRIMARY KEY ( id_club );

--Création de la table Cours

CREATE TABLE cours (
    id_cours NUMBER NOT NULL,
    titre    VARCHAR2(100) NOT NULL
);

ALTER TABLE cours ADD CONSTRAINT cours_pk PRIMARY KEY ( id_cours );

--Création de la table Membre

CREATE TABLE membre (
    id_membre    NUMBER NOT NULL,
    email        VARCHAR2(256) NOT NULL,
    pseudo       VARCHAR2(100) NOT NULL,
    pointage     INTEGER,
    club_id_club NUMBER
);

ALTER TABLE membre ADD CONSTRAINT membre_pk PRIMARY KEY ( id_membre );

--Création de la table pour la relation membre_cours (plusieurs à plusieurs)

CREATE TABLE membre_cours (
    membre_id_membre NUMBER NOT NULL,
    cours_id_cours   NUMBER NOT NULL
);

ALTER TABLE membre_cours ADD CONSTRAINT membre_cours_pk PRIMARY KEY ( membre_id_membre,
                                                                      cours_id_cours );

--Création de la table Tournoi

CREATE TABLE tournoi (
    id_tournoi NUMBER NOT NULL,
    date_debut DATE NOT NULL,
    date_fin   DATE NOT NULL
);

ALTER TABLE tournoi ADD CONSTRAINT tournoi_pk PRIMARY KEY ( id_tournoi );

ALTER TABLE club
    ADD CONSTRAINT club_tournoi_fk FOREIGN KEY ( tournoi_id_tournoi )
        REFERENCES tournoi ( id_tournoi );

ALTER TABLE membre
    ADD CONSTRAINT membre_club_fk FOREIGN KEY ( club_id_club )
        REFERENCES club ( id_club );

ALTER TABLE membre_cours
    ADD CONSTRAINT membre_cours_cours_fk FOREIGN KEY ( cours_id_cours )
        REFERENCES cours ( id_cours );

ALTER TABLE membre_cours
    ADD CONSTRAINT membre_cours_membre_fk FOREIGN KEY ( membre_id_membre )
        REFERENCES membre ( id_membre );

--Insertions des données de base

INSERT INTO Membre (id_membre, email, pseudo, pointage) VALUES (923101,'hikarunakamura@gmail.com','Hikaru',2775);
INSERT INTO Membre (id_membre, email, pseudo, pointage) VALUES (892202,'magnuscarlsen@gmail.com','MagnusCarlsen', 2853);
INSERT INTO Membre (id_membre, email, pseudo, pointage) VALUES (184303,'levyrozman@gmail.com','GothamChess',2322);
INSERT INTO Membre (id_membre, email, pseudo, pointage) VALUES (279404,'alexandrubanzea@gmail.com','Banzeus', 2394);

INSERT INTO Cours (id_cours, titre) VALUES (001,'Comment gagner aux échecs avec les Blancs');
INSERT INTO Cours (id_cours, titre) VALUES (002,'Comment gagner aux échecs avec les Noirs');
INSERT INTO Cours (id_cours, titre) VALUES (003,'Tutoriel sur Ouverture Anglaise');
INSERT INTO Cours (id_cours, titre) VALUES (004,'Tutoriel sur Défense Sicilienne');

INSERT INTO Club (id_club, nom, proprietaire) VALUES (672,'Club des Meilleurs','Rex Sinquefield');
INSERT INTO Club (id_club, nom, proprietaire) VALUES (782,'Club des Redoutables','Yves Leclerc');

INSERT INTO Tournoi (id_tournoi, date_debut, date_fin) VALUES (123321,to_date('2023-05-18','YYYY-MM-DD'),to_date('2023-05-23'));
INSERT INTO Tournoi (id_tournoi, date_debut, date_fin) VALUES (789987,to_date('2023-05-25','YYYY-MM-DD'),to_date('2023-05-29'));

commit;

--Activation du mode REST

BEGIN
    ORDS.enable_schema(
        p_enabled => TRUE,
        p_schema => 'RESTSCOTT',
        p_url_mapping_type => 'BASE_PATH',
        p_url_mapping_pattern => 'echecsProDB',
        p_auto_rest_auth => FALSE
       );
    COMMIT;
END;
/

--REST pour la table Membre

BEGIN
    ORDS.enable_object(
        p_enabled => TRUE,
        p_schema => 'RESTSCOTT',
        p_object => 'MEMBRE',
        p_object_type => 'TABLE',
        p_object_alias => 'membres'
    );
    COMMIT;
END;
/

--REST pour la table Club

BEGIN
    ORDS.enable_object(
        p_enabled => TRUE,
        p_schema => 'RESTSCOTT',
        p_object => 'CLUB',
        p_object_type => 'TABLE',
        p_object_alias => 'clubs'
    );
    COMMIT;
END;
/

--REST pour la table Tournoi

BEGIN
    ORDS.enable_object(
        p_enabled => TRUE,
        p_schema => 'RESTSCOTT',
        p_object => 'TOURNOI',
        p_object_type => 'TABLE',
        p_object_alias => 'tournois'
    );
    COMMIT;
END;
/

--REST pour la table Cours

BEGIN
    ORDS.enable_object(
        p_enabled => TRUE,
        p_schema => 'RESTSCOTT',
        p_object => 'COURS',
        p_object_type => 'TABLE',
        p_object_alias => 'cours'
    );
    COMMIT;
END;
/

--REST pour la table membre_cours

BEGIN
    ORDS.enable_object(
        p_enabled => TRUE,
        p_schema => 'RESTSCOTT',
        p_object => 'MEMBRE_COURS',
        p_object_type => 'TABLE',
        p_object_alias => 'membres_cours'
    );
    COMMIT;
END;
/
